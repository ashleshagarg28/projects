import React from 'react';
import vishal from './vishal.jpg';
import yamini from './yamini.jpg';
import ashlesha from './ashlesha.jpg';
import poorvi from './poorvi.jpg';
import './team.css'

const Team = () =>
{
	return(
			<div id="profiles">
				<div className="vishal">
					<img className="img" src={vishal}/>
					<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
					<center>
						<h4>Vishal Kumar Chopra</h4>
						MCA, 4<sup>th</sup> Semester<br/>MNNIT ALLAHABAD<br/>
						<i>vishal.mca.mnnit@gmail.com</i><br/>
						+91-9984739757			
					</center>		
				</div>
				<div className="yamini">
					<img className="img" src={yamini}/>
					<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
					<center>
						<h4>Yamini</h4>
						MCA, 4<sup>th</sup> Semester<br/>MNNIT ALLAHABAD<br/>
						<i>yamini.mnnit.mca2017@gmail.com</i><br/>
						+91-9654886418			
					</center>		
				</div>
				<div className="ashlesha">
					<img className="img" src={ashlesha}/>
					<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
					<center>
						<h4>Ashlesha Garg</h4>
						MCA, 4<sup>th</sup> Semester<br/>MNNIT ALLAHABAD<br/>
						<i>ashlesha.mnnit2k17@gmail.com</i><br/>
						+91-9649923441			
					</center>		
				</div>
				<div className="poorvi">
					<img className="img" src={poorvi}/>
					<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
					<center>
						<h4>Poorvi Malaviya</h4>
						MCA, 4<sup>th</sup> Semester<br/>MNNIT ALLAHABAD<br/>
						<i>poorvi.mnnit2017@gmail.com</i><br/>
						+91-8604614113			
					</center>		
				</div>
				<br/><br/><br/><br/><br/><br/><br/>
			</div>
		);
}

export default Team;