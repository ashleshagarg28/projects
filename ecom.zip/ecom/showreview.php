<!DOCTYPE html>

<html>
	<head>
		<link rel="icon" href="logo.ico" type="image/x-icon">
		<link rel = "stylesheet" href = "stores.css">	
		<title>Cart: Nutrition Junction</title>
	</head>

	<body>
		<a href="index.html"><img src="logo.jpg" alt="LOGO" height="50" width="50"></a>
        <h1 class="head" align="center"> NUTRITION JUNCTION </h1>
        <div class="cart">
			<?php
            
            $servername = "127.0.0.1";
            $username = "user";
            $password = "user";
            $dbname = "ecom";
    
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    

					$var1=$_GET['id'] ;   
					    
					
						$result= mysqli_query($conn,"SELECT * FROM reviews where productid= '$var1'");
						$row= mysqli_num_rows($result);
						
						if ($row== 0)
						{
						echo "<h1>NO REVIEWS.</h1>";
						}
						else
						{
							echo "<h1>REVIEWS</h1>";
							echo "<h3>ProductID ". $var1 ."</h3>" ;
				
				
							echo "<h2><table border='1'>
							<tr>
							<th>uname</th>
							<th>feedback</th>
							</tr>";
				
							while($row = mysqli_fetch_array($result))
							{
							echo "<tr>";
							echo "<td>" . $row['uname'] . "</td>";
							echo "<td>" . $row['review'] . "</td>";
							echo "</tr>";
							}
							
							echo "</table></h2>";
							$result1= mysqli_query($conn,"SELECT Count(productid) as sum FROM reviews WHERE productid=$var1");
							$row = mysqli_fetch_array($result1);
							
						}
						echo "<button><a href='addreview.php?id=".$var1."'>Add Review</a></button>";
					    
					

					mysqli_close($conn);
					
				?>

				
</div>		
	</body>
</html> 