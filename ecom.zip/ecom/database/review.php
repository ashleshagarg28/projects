<?php

		$servername = "127.0.0.1";
		$username = "user";
		$password = "user";
		$dbname = "ecom";

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


$sql = "CREATE TABLE reviews(

productid VARCHAR(30) NOT NULL,
uname VARCHAR(30) NOT NULL,
review VARCHAR(30) NOT NULL

)";


if (mysqli_query($conn, $sql)) {
    echo "Table products created successfully";
} else {
    echo "Error creating table: " . mysqli_error($conn);
}


  mysqli_query($conn,"SELECT * FROM reviews");
  mysqli_query($conn,"INSERT INTO reviews VALUES ('11','Yamini','Nice Product.' )");
  mysqli_query($conn,"INSERT INTO reviews VALUES ('22','Vishal','Good Product.' )");
  mysqli_query($conn,"INSERT INTO reviews VALUES ('33','Shaily','Worth the money.' )");
  mysqli_query($conn,"INSERT INTO reviews VALUES ('44','User1','Got another product.' )");
  
?>


