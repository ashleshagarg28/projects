<?php

		$servername = "127.0.0.1";
		$username = "user";
		$password = "user";
		$dbname = "ecom";

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


$sql = "CREATE TABLE cart(

productid VARCHAR(30) NOT NULL PRIMARY KEY,
quantity VARCHAR(30) NOT NULL,
price VARCHAR(30) NOT NULL
)";


if (mysqli_query($conn, $sql)) {
    echo "Table products created successfully";
} else {
    echo "Error creating table: " . mysqli_error($conn);
}
?>


