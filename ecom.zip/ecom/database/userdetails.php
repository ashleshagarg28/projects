<?php
session_start();
		$servername = "127.0.0.1";
		$username = "user";
		$password = "user";
		$dbname = "ecom";

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


$sql = "CREATE TABLE userdetails(

uname VARCHAR(30) NOT NULL ,
phn VARCHAR(30) NOT NULL,
d_address VARCHAR(50) NOT NULL,
email VARCHAR(10) NOT NULL PRIMARY KEY,
pass VARCHAR(50) NOT NULL
)";



if (mysqli_query($conn, $sql)) {
    echo "Table MyGuests created successfully";
} else {
    echo "Error creating table: " . mysqli_error($conn);
}


mysqli_close($conn);




?>


