<?php

		$servername = "127.0.0.1";
		$username = "user";
		$password = "user";
		$dbname = "ecom";

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


$sql = "CREATE TABLE products(

productid VARCHAR(30) NOT NULL PRIMARY KEY,
pname VARCHAR(30) NOT NULL,
quantity VARCHAR(30) NOT NULL,
price VARCHAR(30) NOT NULL,
mass VARCHAR(10) NOT NULL
)";


if (mysqli_query($conn, $sql)) {
    echo "Table products created successfully";
} else {
    echo "Error creating table: " . mysqli_error($conn);
}


  mysqli_query($conn,"SELECT * FROM products");
  mysqli_query($conn,"INSERT INTO products VALUES ('11','True-Mass',1000, 3000,' 2.6kg' )");
  mysqli_query($conn,"INSERT INTO products VALUES ('22','TISO-100 (Whey Protein Powder for Building Muscle)',1000,2500,'2.5 kg' )");
  mysqli_query($conn,"INSERT INTO products VALUES ('33','Pro JYM (Blended Protein Supplement)',1000,3090,'500 grams' )");
  mysqli_query($conn,"INSERT INTO products VALUES ('44','Gold Standard (Muscle Building Whey Protein Powder)',1000,2290,'900 grams' )");
  
?>


