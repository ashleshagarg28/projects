
      
    <?php
    

        if(array_key_exists('submit', $_GET)) { 
            button1(); 
        } 
        else if(array_key_exists('review', $_GET)) { 
            button2(); 
        } 
        function button1() { 
            $var1=$_GET['id'];
            $var2=$_GET['quant'];
            $var3=$_GET['price'];
       /*<a href="addtocart.php?id=<?php echo "$var1";?>&quant=<?php echo "$var2";?>&price=<?php echo "$var3";?>">DELETE</a>*/
           $url = "http://localhost/ecom/addtocart.php?id=".$var1."&quant=".$var2."&price=".$var3;
          // $url = "http://localhost/main.php?event_id=".$event_id."&email=".$email;
          header ("location: $url");

        } 
        function button2() { 
            $var1=$_GET['id'];
            
           /* <a href="addreview.php?id=<?php echo "$var1"; ?>">Page2</a>*/
           $url = "http://localhost/ecom/showreview.php?id=".$var1;
           header ("location: $url");

        } 
    ?> 
  