
<?php
session_start();
$var1=$_GET['id'];
$var2=$_GET['quant'];
$var3=$_GET['price'];

        $servername = "127.0.0.1";
		$username = "user";
		$password = "user";
		$dbname = "ecom";

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$result1= mysqli_query($conn,"SELECT quantity AS val FROM products WHERE productid='$var1'");
$row = mysqli_fetch_array($result1);

if($row['val']>=$var2)
{	
	$result2= mysqli_query($conn,"SELECT quantity FROM cart WHERE productid='$var1'");
	$row2 = mysqli_fetch_array($result2);
	if(mysqli_num_rows($result2) > 0){
		$check1 = $row2['quantity'];
		$newQ = $var2+$check1;
		$var4=$var3*$newQ;
		$var5=$var4*(0.15);
		$_SESSION["save"]=$var5;
		$Fprice=$var4-$var5;
		mysqli_query($conn,"UPDATE cart SET quantity='$newQ', price='$Fprice' WHERE productid='$var1'");
	}
	else{				
		$var4=$var3*$var2;
		$var5=$var4*(0.15);
		$_SESSION["save"]=$_SESSION["save"]+$var5;
		$Fprice=$var4-$var5;
		mysqli_query($conn,"INSERT INTO cart VALUES ('$var1','$var2','$Fprice' )");
	}
    mysqli_query($conn,"UPDATE products SET quantity=quantity-$var2 WHERE productid='$var1' AND quantity > 0");
   ?>

    <script type='text/javascript'>
    alert('Item added to the cart.');
    window.location.replace("store1.html");
</script>
<?php
}
else
{
    ?>

    <script type='text/javascript'>
    alert('Stock out!!!');
    window.location.replace("store1.html");
</script>
<?php

}

?>





