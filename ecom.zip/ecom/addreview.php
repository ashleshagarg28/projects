<!DOCTYPE html>

<html>
	<head>
		<link rel="icon" href="logo.ico" type="image/x-icon">
		<link rel = "stylesheet" href = "stores.css">	
		<title>Cart: Nutrition Junction</title>
	</head>

	<body>
		<a href="index.html"><img src="logo.jpg" alt="LOGO" height="50" width="50"></a>
        <h1 class="head" align="center"> NUTRITION JUNCTION </h1>
        <div class="cart">
      
<?php
            
            $servername = "127.0.0.1";
            $username = "user";
            $password = "user";
            $dbname = "ecom";
    
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    
    $var1=$_GET['id'];
    echo "<h1>Product Id is $var1</h1>";
   ?>
    <html>
    <body>
<form action="" method="POST">
                    <input type ="hidden" name="id" value="<?php echo $var1;?>"></input>
					<h2>Name :<input type="text" name="uname" ></input><br/>
					Review: <input name="review" type=text required></input></h2>
                <button type="submit" name="action" value="post">Post Review</button> 
                
            </form>
</body>
    </html>

    <?php
 
    if (isset($_POST['action'])) {
        $var1=$_POST['id'] ;       
        $var8=$_POST['uname'];
        $var9=$_POST['review'];

        $sql = "INSERT INTO REVIEWS VALUES ('$var1','$var8','$var9' )"; 
            if (mysqli_query($conn, $sql)) {
                echo "Your Feedback is posted successfully!!!";
            } else {
                echo "Error: " . $sql . "<br>" . mysqli_error($conn);
            }
    }
   // echo "<button><a href='details.html'>Pay Now</a></button>";
 
                    mysqli_close($conn);

 ?>

</div>		
	</body>
</html> 