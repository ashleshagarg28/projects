

<html>

<form id="s" action="addtocart.php" method="post" onsubmit = "return check();">
<center></br>
   
        <button type="submit">Buy Now</button>

</center>
</form>	
</html>
<?php

        $servername = "127.0.0.1";
		$username = "user";
		$password = "user";
		$dbname = "ecom";

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

		$var2 = 3;

  mysqli_query($conn,"SELECT * FROM cart");
  mysqli_query($conn,"SELECT * FROM signup");

  mysqli_query($conn,"INSERT INTO cart  (SELECT * FROM ecom.signup)");

$sql = "UPDATE orderid SET orderid='$var1' WHERE uname='$uname'";
if (mysqli_query($conn, $sql)) {
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . mysqli_error($conn);}

if(isset($_POST['submit']))
   {
        header('Location: index.html');
   }

?>


