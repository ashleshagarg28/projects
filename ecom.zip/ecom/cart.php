<!DOCTYPE html>

<html>
	<head>
		<link rel="icon" href="logo.ico" type="image/x-icon">
		<link rel = "stylesheet" href = "stores.css">	
		<title>Cart: Nutrition Junction</title>
	</head>

	<body>
		<a href="index.html"><img src="logo.jpg" alt="LOGO" height="50" width="50"></a>
        <h1 class="head" align="center"> NUTRITION JUNCTION </h1>
        <div class="cart">
            <?php
            session_start();
            $conn = new mysqli("127.0.0.1","user","user","ecom");
            if(mysqli_connect_errno()) {
                printf("Connect Failed: %s\n", mysqli_connect_errno());
                exit();
            }

                $result= mysqli_query($conn,"SELECT * FROM cart");
                $row= mysqli_num_rows($result);
                
                if ($row== 0)
                {
                echo "<h1>Your CART is Empty!!!</h1>";
                }
                else
                {
                    echo "<h1>CART</h1>";
                    
                    echo "<h2><table border='1'>
                    <tr>
                    <th>Product Name</th>
                    <th>Quantity</th>
                    <th>Price</th>
                    <th>Operation</th>
                    </tr>";
                    
                    while($row = mysqli_fetch_array($result))
                    {
                    echo "<tr>";
                    echo "<td>" . $row['productid'] . "</td>";
                    echo "<td>" . $row['quantity'] . "</td>";
                    echo "<td>" . $row['price'] . "</td>";
                    echo "<td> <button><a href='delete.php?value=".$row['productid']."&quant=".$row['quantity']."'>Remove</a></button> </td>";
                    echo "</tr>";
                    }
                    
                    echo "</table></h2>";
                    $result1= mysqli_query($conn,"SELECT SUM(price) as sum FROM cart");
                    $row = mysqli_fetch_array($result1);
                    echo "<h2>Cart Total : ₹ ".$row['sum']."</h2>";
                    echo "<h2>Total Savings : ₹ ".$_SESSION["save"]."</h2>";
                    echo "<button><a href='details.html'>Pay Now</a></button>";
                }

            
            
                
            /*$result = mysqli_query($conn,"SELECT * FROM cart");
            */
            mysqli_close($conn);

            ?>
        </div>		
	</body>
</html> 