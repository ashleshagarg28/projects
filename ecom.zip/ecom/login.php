 <?php
 /*
 session_start();
 error_reporting(0);
 
 if(isset($_SESSION['username'])) {
  header("Location: /"); // redirects them to homepage
  exit; // for good measure
}
    session_start();
    */

    $servername = "127.0.0.1";
    $username = "user";
    $password = "user";
    $dbname = "ecom";

    // Create connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    // Check connection
    if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
    }

    $var1= $_POST["email"];
    $var2= $_POST["pass"];

    //$_SESSION['email']="$var1";
    
    $sql = "SELECT pass FROM userdetails WHERE email= '$var1'";

    $result = mysqli_query($conn,$sql);
    $row=mysqli_fetch_assoc($result) ;
    
    if(mysqli_num_rows($result) > 0)
    {
      if($var2==$row["pass"])
      {?>
      <script>
        alert("Password match!");
      </script>
      <meta http-equiv="refresh" content="1; url=index.html" />
      <?php

	if(isset($_GET['submit']))
   {
        header('Location: index.html');
   }

      }
      else
      {?>
      <script>
        alert("Wrong information!");
      </script>
      <meta http-equiv="refresh" content="1;url=index.html" />
      <?php
      }
    }
    else
    {
      ?>
      <script>
        alert("Wrong information!");
      </script>
      <meta http-equiv="refresh" content="1;url=index.html" />
      <?php
    }

    mysqli_close($conn);
    ?>