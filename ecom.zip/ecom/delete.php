<?php
$value=$_GET['value'];
$quant=$_GET['quant'];
$con=mysqli_connect("127.0.0.1","user","user","ecom");

if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
  
$sql = "DELETE FROM cart WHERE productid='$value'";
mysqli_query($con,"UPDATE products SET quantity= quantity+$quant WHERE productid='$value' ");

$_SESSION["save"]=0;

if ($con->query($sql) === TRUE) {
    header('Location: cart.php');
} else {
    echo "Error deleting record: " . $con->error;
}
mysqli_close($conn);
?>