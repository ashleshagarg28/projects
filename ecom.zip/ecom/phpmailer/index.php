<?php
session_start();
require 'phpmailer/PHPMailerAutoload.php';

//create an instance of php mailer
$mail = new PHPMailer();

//enable smtp
$mail->isSMTP();

//set a host
$mail->Host = "smtp.gmail.com";

//set type of protection
$mail->SMTPSecure = "TLS";//if TLS,port=587
$mail->Port = 587;

//set authentication to true
$mail->SMTPAuth = true;

//login details for account
$mail->Username = 'vishal.mca.mnnit@gmail.com';
$mail->Password = 'MNNIT@2020';

$mail->setFrom('vishal.mca.mnnit@gmail.com', 'Nutrition Junction');

$mail->addAddress($_SESSION["email"]);
//$mail->addAddress('wishalkchopra@gmail.com');
//setting up the subject
$mail->Subject = 'Nutrition Junction: Order Confirmation';
$mail->IsHTML(true);
//setting body for mail
$mail->Body = 'Thanks for purchasing from us!><br/><br/>
------------------------<br/>
<i>Thanks and regards,</i><br/>
<i>Team NJ</i>';
 

if ($mail->send()){
	header('location:./../payment.html');
}
else
	echo "Error";


?>
