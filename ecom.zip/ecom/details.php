<?php
session_start();
		$servername = "127.0.0.1";
		$username = "user";
		$password = "user";
		$dbname = "ecom";

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

/*
$sql = "CREATE TABLE userdetails(

uname VARCHAR(30) NOT NULL ,
phn VARCHAR(30) NOT NULL,
d_address VARCHAR(50) NOT NULL,
email VARCHAR(10) NOT NULL PRIMARY KEY,
pass VARCHAR(50) NOT NULL
)";



if (mysqli_query($conn, $sql)) {
    echo "Table MyGuests created successfully";
} else {
    echo "Error creating table: " . mysqli_error($conn);
}
*/

mysqli_close($conn);



		$var1 = $_POST['uname'];	
		$var4 = $_POST['phn'];
		$var5 = $_POST['d_address'];
        $var6 = $_POST['email'];
		$var7 = $_POST['pass'];
		


$con=mysqli_connect("127.0.0.1","user","user","ecom");
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
  mysqli_query($con,"SELECT * FROM userdetails");
  mysqli_query($con,"INSERT INTO userdetails VALUES ('$var1','$var4','$var5','$var6','$var7' )");
  mysqli_query($con,"SELECT * FROM cart");

  mysqli_query($con,"DELETE FROM cart");
  $_SESSION["save"]=0;
  //Mailing system 
	$_SESSION["email"] = $var6;
	header('location:./phpmailer/index.php');

?>


